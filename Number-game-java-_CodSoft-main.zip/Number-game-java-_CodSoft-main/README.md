# Number-game-java-_CodSoft
The "NumberGame" project is a Java Swing-based application that allows users to play a guessing game. The game randomly generates a number within a specified range, and the user has to guess the correct number. The program provides feedback on whether the user's guess is correct, too high,or too low.
